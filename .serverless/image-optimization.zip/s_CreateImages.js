
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'lukhee',
  applicationName: 'personal-project',
  appUid: 'SGY20vhVkC27khvLgc',
  orgUid: '31569b54-b095-4d31-aa59-b64716c23adf',
  deploymentUid: '05a54028-319f-4584-b3b2-5992c6affbaa',
  serviceName: 'image-optimization',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'image-optimization-dev-CreateImages', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/createImages.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}