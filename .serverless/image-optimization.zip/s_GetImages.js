
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'lukhee',
  applicationName: 'personal-project',
  appUid: 'SGY20vhVkC27khvLgc',
  orgUid: '31569b54-b095-4d31-aa59-b64716c23adf',
  deploymentUid: '0d85bf4b-c01d-43db-873e-3b34f732a32e',
  serviceName: 'image-optimization',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'image-optimization-dev-GetImages', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/getImages.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}